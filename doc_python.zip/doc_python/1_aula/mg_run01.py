import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from IPython.display import display
from matplotlib import pyplot
import datetime as dt

dfNY = pd.read_csv("https://www.dropbox.com/s/8i2nw6bd5ha7vny/listingsNY.csv?dl=1")
dfRJ = pd.read_csv("https://www.dropbox.com/s/yyg8hso7fbjf1ft/listingsRJ.csv?dl=1")
"""
id: identificação de cada imovel
hot_id: o número de identificação do anfitrião
neighboarhood_group: conjunto de grupo de bairro
latitude - coordenada latitude 
longitude: coordenada longirtude
room_type: o tipo de quarto
price: valor da pernoite do imovel
minimun_nights: noites minimas para locação
numer_of_reviews: número de avaliação
last_review: data da ultima avaliação
reviews_per_month: quantidade de avaliação por mês
calculated_host_listing_count: quantidade de imoveis do mesmo anfitrião
availability_365: dias em que o anuncio esta disponivel
number_reviews_ltm: avaliação nos ultimos 12 meses
license: nenhum valor valido
display(dfNY.head(5))
print(f'New York \nEntradas: {dfNY.shape[0]}\nVariaveis: {dfNY.shape[1]}\n')
display(dfRJ.head(5))
print(f'Rio de Janeiro \nEntradas: {dfRJ.shape[0]}\nVariaveis: {dfRJ.shape[0]}\n')
"""


display(dfNY.dtypes)
dfNY.last_review = pd.to_datetime(dfNY.last_review, format="%Y-%m-%d")
print(dfNY.last_review)
dfNY['year']= dfNY.last_review.dt.year
dfNY.price = dfNY.price.mask(dfNY.year <= 2011,(dfNY.price / 1.7456))
dfNY.price = dfNY.price.mask(dfNY.year <= 2012,(dfNY.price / 1.876))
dfNY.price = dfNY.price.mask(dfNY.year <= 2013,(dfNY.price / 1.9956))
dfNY.price = dfNY.price.mask(dfNY.year <= 2014,(dfNY.price / 2.1456))
dfNY.price = dfNY.price.mask(dfNY.year <= 2015,(dfNY.price / 2.3456))
dfNY.price = dfNY.price.mask(dfNY.year <= 2016,(dfNY.price / 2.5456))
dfNY.price = dfNY.price.mask(dfNY.year <= 2017,(dfNY.price / 2.6456))
dfNY.price = dfNY.price.mask(dfNY.year <= 2018,(dfNY.price / 2.7456))
dfNY.price = dfNY.price.mask(dfNY.year <= 2019,(dfNY.price / 2.9456))
dfNY.price = dfNY.price.mask(dfNY.year <= 2020,(dfNY.price / 3.0456))
dfNY.price = dfNY.price.mask(dfNY.year <= 2021,(dfNY.price / 3.27456))




variaveis = ['id',
             'name',
             'host_id',
             'host_name',
             'neighbourhood_group',
             'neighbourhood',
             'latitude',
             'longitude',
             'room_type',
             'price',
             'minimum_nights',
             'number_of_reviews',
             'last_review',
             'reviews_per_month',
             'calculated_host_listings_count',
             'availability_365',
             'number_of_reviews_ltm',
             'license'
            ]
vz = []
dado = []

for i in variaveis:
    dado.append(dfNY[i].isnull().sum() / dfNY[i].shape[0])
    dado.append(dfRJ[i].isnull().sum() / dfRJ[i].shape[0])
    vz.append(dado[:])
    dado.clear()

pd.DataFrame(vz, columns=['New York','Rio de Janeiro'], index = variaveis)

dfNY_clean = dfNY.dropna(subset=['name','host_name'], axis=0)

rpm_ny_median = dfNY_clean.reviews_per_month.median()
dfNY_clean = dfNY_clean.fillna({"reviews_per_month": rpm_ny_median})
lr_ny_median = dfNY_clean['last_review'].astype('datetime64[ns]').quantile(0.5, interpolation="midpoint")
dfNY_clean = dfNY_clean.fillna({"last_review": lr_ny_median})

dfRJ_clean = dfRJ.dropna(subset=['name','host_name'], axis=0)

rpm_rj_median = dfRJ_clean.reviews_per_month.median()
dfRJ_clean = dfRJ_clean.fillna({"reviews_per_month": rpm_rj_median})
lr_rj_median = dfRJ_clean['last_review'].astype('datetime64[ns]').quantile(0.5, interpolation="midpoint")
dfRJ_clean = dfRJ_clean.fillna({"last_review": lr_rj_median})

dx0 = ['price', 'minimum_nights']

for n in dx0:
    data_a = dfNY_clean[n]
    data_b = dfRJ_clean[n]
    data_2d = [data_a, data_b]
    plt.boxplot(data_2d, vert= False, labels=["New York", "Rio de Janeiro" ])
    plt.title(n)
plt.show()

dfNY_clean[['price', 
             'minimum_nights', 
             'number_of_reviews', 
             'last_review',
             'reviews_per_month', 
             'calculated_host_listings_count', 
             'availability_365'
             ]].describe()

dfRJ_clean[['price', 
             'minimum_nights', 
             'number_of_reviews', 
             'last_review',
             'reviews_per_month', 
             'calculated_host_listings_count', 
             'availability_365'
             ]].describe()

dfNY_out = dfNY_clean.copy()
dfNY_out.drop(dfNY_out[dfNY_out.price > 1100].index, axis=0, inplace=True)


dfRJ_out = dfRJ_clean.copy()
dfRJ_out.drop(dfRJ_out[dfRJ_out.price > 1100].index, axis=0, inplace=True)

var = ['Entire home/apt',
        'Private room',
        'Shared room',
        'Hotel room']

dado_var = {}

for i in var:
    dado_var[i] = [dfNY_out.loc[dfNY_out.room_type==i].shape[0] / dfNY_out.room_type.shape[0], dfRJ_out.loc[dfRJ_out.room_type==i].shape[0] / dfRJ_out.room_type.shape[0]]

ima = pd.DataFrame(dado_var, index=['Nova York','Rio de Janeiro'])
ima.plot(kind="barh", stacked=True, figsize=(6,4), color=['c','m','y','orange'])

plt.legend(loc="lower left", bbox_to_anchor=(0.8,1.0))
plt.show()